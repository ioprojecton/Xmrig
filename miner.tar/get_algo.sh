get_algo(){
temp=$(mktemp -t temp.XXXXXX)
algo_array=("cn/upx2" "argon2/chukwav2" "cn/ccx" "kawpow" \
 "rx/keva" "astrobwt" "cn-pico/tlo" "rx/sfx" "rx/arq" \
 "rx/0" "argon2/chukwa" "argon2/ninja" "rx/wow" "cn/fast" \
 "cn/rwz" "cn/zls" "cn/double" "cn/r" "cn-pico" "cn/half" \
 "cn/2" "cn/xao" "cn/rto" "cn-heavy/tube" "cn-heavy/xhv" \
 "cn-heavy/0" "cn/1" "cn-lite/1" "cn-lite/0" "cn/0" "gr")

dialog --title "Algorithm Selection" \
--radiolist "!!!You need FULL install to use different algos!!!" \
30 32 "${#algo_array[@]}" \
1 "uPlexa(cn/upx2)" OFF \
2 "Argon2id/Chukwa v2" OFF \
3 "Conceal(ccx)" OFF \
4 "Kawpow" OFF \
5 "RandomKeva" OFF \
6 "AstroBWT" OFF \
7 "CryptoNight-Pico" OFF \
8 "RandomSFX" OFF \
9 "RandomARQ" OFF \
10 "RandomX" ON \
11 "Argon2id(Chukwa)" OFF \
12 "Argon2id(Ninja)" OFF \
13 "RandomWoW" OFF \
14 "cn/fast" OFF \
15 "cn/rwz" OFF \
16 "cn/zls" OFF \
17 "cn/double" OFF \
18 "cn/r" OFF \
19 "cn-pico" OFF \
20 "cn/half" OFF \
21 "cn/2" OFF \
22 "cn/xao" OFF \
23 "cn/rto" OFF \
24 "cn-heavy/tube" OFF \
25 "cn-heavy/xhv" OFF \
26 "cn-heavy/0" OFF \
27 "cn/1" OFF \
28 "cn-lite/1" OFF \
29 "cn-lite/0" OFF \
30 "cn/0" OFF \
31 "Ghost Rider" OFF 2> "$temp"
algo="${algo_array[(($(cat "$temp")-1))]}"

dialog --title "Selected Algorithm" --msgbox "$algo" 5 32
rm -f "$temp" 2> /dev/null
update_config 7 "$algo"
}
