get_id(){
temp=$(mktemp -t temp.XXXXXX)

dialog --title "Enter workers ID" --inputbox \
"Default:myID" 8 25 2> "$temp"

id=$(cat "$temp")
if [ -z "$id" ]
then id="myID"
fi
dialog --title "ID" --msgbox "$id" 8 25
rm -f "$temp" 2> /dev/null
update_config 4 "$id"
}
