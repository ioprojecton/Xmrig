get_firewall(){
temp=$(mktemp -t temp.XXXXXX)

dialog --yesno "Bypass firewall" 5 20

if [ "$?" -eq 0 ]
then update_config 2 1 #tls=1
else update_config 2 0 #tls=2
fi
rm -f "$temp" 2> /dev/null
}
 
