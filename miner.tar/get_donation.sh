donation_level(){
temp=$(mktemp -t temp.XXXXXX)
dialog --title "Donation Level" \
--radiolist "Select level" 14 18 6 \
0 "" ON \
1 "" OFF \
2 "" OFF \
3 "" OFF \
4 "" OFF \
5 "" OFF 2> "$temp"

donation_level=$(cat "$temp")

dialog --title "Donation Level" --msgbox "$donation_level minutes\
 in 100 minutes" 5 28
update_config 5 "$donation_level"
rm -f "$temp"
}
