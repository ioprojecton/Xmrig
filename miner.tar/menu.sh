menu(){
temp=$(mktemp -t temp.XXXXXX)

while [ 1 ]
do
dialog --menu "Sys info" 12 25 4 1 "Hardware info" 2 "Configure Xmrig" 3 \
"Start Xmrig" 4 "Exit" 2> "$temp"

if [ "$?" -eq 1 ]
then break
fi

option=$(cat "$temp")
case $option in
0)break;;
1)hw_info
show_hardware_info;;
2)configure_xmrig;;
3)start_xmrig;;
4)break;;
*)dialog --msgbox "Wrong Selection" 10 30;;
esac

done
rm -f "$temp" 2> /dev/null
clear
}
