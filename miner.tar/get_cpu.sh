get_cpu(){
temp=$(mktemp -t temp.XXXXXX)
radiolist=""
counter=1
while [ "$counter" -le "$(nproc)" ]
do
if [ "$counter" -eq "$(("$(nproc)"-1))" ]
then radiolist+="$counter threads ON "
else radiolist+="$counter threads OFF "
fi
((counter++))
done

dialog --title "CPU threads" \
--radiolist "Select CPU threads" \
11 12 "$(nproc)" \
$radiolist 2> "$temp"

thread_count=$(cat "$temp")

update_config 6 "$thread_count"
rm -f "$temp" 2> /dev/null

}
