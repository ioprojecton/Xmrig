get_address(){
temp=$(mktemp -t temp.XXXXXX)

dialog --title "Enter wallet address" --inputbox \
"Default:donationwallet" 7 45 2> "$temp"

wallet=$(cat "$temp")

if [ -z "$wallet" ]
then wallet="47i1E6mY3AWUBb7jbLMP7XP2brFJ9wcpBdwMLbdLVL\
VJ8KHFMdys2KwGxVydjyfHogPQQaZyTTCWt7PenQy27BJhNL2uDBm"
fi

dialog --title "Wallet" --msgbox "$wallet" 10 40
rm -f "$temp" 2> /dev/null
update_config 3 "$wallet"
}
