update_config(){
counter=1
while read line
do
if [ "$counter" -eq "$1" ]
then echo "$1:$2"
else echo "$line"
fi
((counter++))
done < myFile > myNewFile
rm myFile
mv myNewFile myFile
counter=1
}

