get_pool(){
temp=$(mktemp -t temp.XXXXXX)

dialog --title "Enter pool name" --inputbox \
"Default:pool.supportxmr.com:3333" 7 40 2> "$temp"

pool=$(cat "$temp")

if [ -z "$pool" ]
then pool="pool.supportxmr.com:3333"
fi
dialog --title "Pool" --msgbox "Pool=$pool" 5 40

update_config 1 "$pool"

rm -f "$temp" 2> /dev/null
}
